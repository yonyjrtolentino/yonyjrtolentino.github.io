Recursos de marca · Yoni's Stream

Deja alrededor del logo un margen libre igual a la cuarta parte de su altura (la medida «x»). Ahí no van textos, otros logos ni bordes.

Tamaño mínimo:
- Símbolo: 24 px de alto en pantalla, 10 mm en papel.
- Logo horizontal: 120 px de ancho en pantalla, 35 mm en papel.
- Icono de la app: 48 px.

Colores:
- Verde señal: #10D188 (RGB 16 209 136)
- Noche de estudio: #021514 (RGB 2 21 20)
- Blanco estudio: #F2FFF9 (RGB 242 255 249)
- Rojo en vivo: #FF2D55 (RGB 255 45 85)
- Ámbar: #FFB020 (RGB 255 176 32)
- Verde profundo: #0A7A50 (RGB 10 122 80)

Tipografías: Montserrat Black, Inter. Las dos son gratuitas (licencia SIL Open Font) y están en Google Fonts.

Yoni's Stream: con Y y S mayúsculas y apóstrofo. En el logotipo va todo en mayúsculas: YONI'S STREAM.

Puedes usar estos recursos para hablar de Yoni's Stream, reseñarla o enlazar su ficha de Google Play. No los uses para dar a entender que la app patrocina o respalda algo sin permiso.
¿Prensa o colaboraciones? Escríbenos a yonisstreamstudio@gmail.com

https://yonisstream.com/marca.html

----

Brand assets · Yoni's Stream

Leave clear space around the logo equal to a quarter of its height (the "x" measure). No text, other logos or borders go there.

Minimum size:
- Symbol: 24 px tall on screen, 10 mm in print.
- Horizontal logo: 120 px wide on screen, 35 mm in print.
- App icon: 48 px.

Colors:
- Signal green: #10D188 (RGB 16 209 136)
- Studio night: #021514 (RGB 2 21 20)
- Studio white: #F2FFF9 (RGB 242 255 249)
- Live red: #FF2D55 (RGB 255 45 85)
- Amber: #FFB020 (RGB 255 176 32)
- Deep green: #0A7A50 (RGB 10 122 80)

Typefaces: Montserrat Black, Inter. Both are free (SIL Open Font License) and available on Google Fonts.

Yoni's Stream: capital Y and S, with an apostrophe. The logotype is all caps: YONI'S STREAM.

You may use these assets to talk about Yoni's Stream, review it or link to its Google Play listing. Don't use them to suggest the app sponsors or endorses something without permission.
Press or partnerships? Write to yonisstreamstudio@gmail.com

https://yonisstream.com/brand.html

----
